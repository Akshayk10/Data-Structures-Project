# S2-DSA-Project
I have created a hospital token generator system and it uses basic GUI using Jswing. It will give a list of doctors
we can choose from and we can give the condition of patient as normal or serious. Download the zip file to check it out!
Kudos!
